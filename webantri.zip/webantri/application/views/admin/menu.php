<li><a href="<?php echo base_url() ?>admin"><i class="fa fa-book"></i> <span>Dashboard</span></a></li>
<li class="treeview">
  <a href="#">
    <i class="fa fa-dashboard"></i> <span>Menu</span>
    <span class="pull-right-container">
      <i class="fa fa-angle-left pull-right"></i>
    </span>
  </a>
  <ul class="treeview-menu">
    <li><a href="<?php echo base_url() ?>admin/layanan"><i class="fa fa-circle-o"></i> Manajemen Layanan</a></li>
    <li><a href="<?php echo base_url() ?>admin/loket"><i class="fa fa-circle-o"></i> Manajemen Loket</a></li>
    <li><a href="<?php echo base_url() ?>admin/user"><i class="fa fa-circle-o"></i> Manajemen User</a></li>
    <li><a href="<?php echo base_url() ?>admin/waktu"><i class="fa fa-circle-o"></i> Manajemen Waktu</a></li>
  </ul>
</li>

<li class="treeview">
  <a href="#">
    <i class="fa fa-dashboard"></i> <span>Pengaturan</span>
    <span class="pull-right-container">
      <i class="fa fa-angle-left pull-right"></i>
    </span>
  </a>
  <ul class="treeview-menu">
    <li><a href="<?php echo base_url() ?>admin/android-gambar"><i class="fa fa-circle-o"></i> Gambar Android</a></li>
    <li><a href="<?php echo base_url() ?>admin/aplikasi"><i class="fa fa-circle-o"></i> Pengaturan Aplikasi</a></li>
 <!--    <li><a href="<?php echo base_url() ?>admin/maksimal-antrian"><i class="fa fa-circle-o"></i> Maksimal Antrian</a></li>
    <li><a href="<?php echo base_url() ?>admin/maksimal-jarak"><i class="fa fa-circle-o"></i> Maksimal Jarak</a></li>
    <li><a href="<?php echo base_url() ?>admin/notifikasi"><i class="fa fa-circle-o"></i> Notifikasi Android</a></li> -->
  </ul>
</li>
